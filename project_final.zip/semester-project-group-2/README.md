# semester-project-group-2
semester-project-group-2 created by GitHub Classroom

Team members
  Coy Kwan, Feng Zheng, Anna Johnson, Cori Mroz, Daylan Quinn
  
Roles
  Project Manager: Coy Kwan
  Front End: Cori 
  FullStack/Testing: Daylan, Feng, Anna
Team Rules
  One meeting per week (planning on Wedsnesday afternoon but flexible)
  3-4 weekly updates on discord 
  ~3 hours a week time comitiment
  
## Members

  Feng Zheng
  
  Coy Kwan

  Daylan Quinn
  
  Cori Mroz
  
  Anna Johnson
